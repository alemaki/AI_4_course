compile src.py
Python 3.9+ required (might or might not work for lower)

board is indexed from 0. For ex.: second row first column would be indexed 1 0
horizontal is 0 or 1.


Planning on making the lines be indexed with points. like from to point.
Also, player is always first now, will change that.
