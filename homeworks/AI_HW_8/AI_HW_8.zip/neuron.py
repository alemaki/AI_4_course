class Neuron():
    def __init__(self) -> None:
        self.value = 0
